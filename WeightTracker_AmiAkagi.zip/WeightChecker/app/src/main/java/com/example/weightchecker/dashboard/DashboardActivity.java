package com.example.weightchecker.dashboard;

import androidx.appcompat.app.AppCompatActivity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import androidx.core.content.ContextCompat;
import com.example.weightchecker.R;
import com.example.weightchecker.auth.UserDatabaseHelper;
import com.example.weightchecker.sms.SMSNotificationActivity;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class DashboardActivity extends AppCompatActivity {

    ListView weightListView;
    ArrayList<String[]> weightList;
    UserDatabaseHelper dbHelper;
    TextView currentWeightText, dateTextView;
    String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        Toast.makeText(this, "Press Settings button to enter SMS Notification screen", Toast.LENGTH_SHORT).show();

        weightListView = findViewById(R.id.weightListView);
        currentWeightText = findViewById(R.id.currentWeight);
        dateTextView = findViewById(R.id.textDate);
        dbHelper = new UserDatabaseHelper(this);

        userId = getIntent().getStringExtra("userId");
        if (userId == null) userId = "default";

        // Set today's date
        String today = new SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()).format(new Date());
        dateTextView.setText(today);

        // Set latest weight from DB
        currentWeightText.setText(dbHelper.getLatestWeight(userId));

        try {
            weightList = dbHelper.getAllWeights(userId);
            Log.d("DashboardActivity", "getAllWeights() result: " + weightList.size());
        } catch (Exception e) {
            Log.e("DB", "getAllWeights error: " + e.getMessage());
            weightList = null;
        }

        refreshWeightList();

        ImageButton smsButton = findViewById(R.id.buttonSMS);
        smsButton.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, SMSNotificationActivity.class);
            startActivity(intent);
        });

        ImageButton addButton = findViewById(R.id.btnAdd);
        addButton.setOnClickListener(v -> showAddWeightDialog());
    }

    private void showAddWeightDialog() {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_add_weight, null);
        EditText inputDate = dialogView.findViewById(R.id.inputDate);
        EditText inputWeight = dialogView.findViewById(R.id.inputWeight);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Add Body Weight")
                .setView(dialogView)
                .setPositiveButton("Save", (dialogInterface, which) -> {
                    String date = inputDate.getText().toString().trim();
                    String weightStr = inputWeight.getText().toString().trim();

                    if (date.isEmpty() || weightStr.isEmpty()) {
                        Toast.makeText(this, "Please enter both date and weight", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    try {
                        double weight = Double.parseDouble(weightStr);
                        dbHelper.insertWeight(userId, date, weight);
                        refreshWeightList();
                        currentWeightText.setText(dbHelper.getLatestWeight(userId));
                        Toast.makeText(this, "Weight saved!", Toast.LENGTH_SHORT).show();
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Invalid number format. Please enter like 55.5", Toast.LENGTH_LONG).show();
                        Log.e("Dashboard", "Invalid weight input: " + weightStr, e);
                    }
                })
                .setNegativeButton("Cancel", null)
                .create();

        dialog.show();

        Button cancelButton = dialog.getButton(AlertDialog.BUTTON_NEGATIVE);
        if (cancelButton != null) {
            cancelButton.setTextColor(ContextCompat.getColor(this, R.color.text_error));
        }
    }

    private void refreshWeightList() {
        weightList = dbHelper.getAllWeights(userId);
        if (weightList == null || weightList.isEmpty()) {
            String[] placeholder = {"Data is empty", ""};
            weightList = new ArrayList<>();
            weightList.add(placeholder);
        }

        weightListView.setAdapter(new BaseAdapter() {
            @Override
            public int getCount() {
                return weightList.size();
            }

            @Override
            public Object getItem(int position) {
                return weightList.get(position);
            }

            @Override
            public long getItemId(int position) {
                return position;
            }

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view;
                if (convertView == null) {
                    view = LayoutInflater.from(DashboardActivity.this)
                            .inflate(R.layout.list_bw_item, parent, false);
                } else {
                    view = convertView;
                }

                TextView dateText = view.findViewById(R.id.textDate);
                TextView weightText = view.findViewById(R.id.textWeight);
                ImageButton deleteButton = view.findViewById(R.id.deleteButton);

                String[] item = weightList.get(position);
                dateText.setText(item[0]);
                weightText.setText(item[1]);

                if (item[0].equals("Data is empty")) {
                    if (deleteButton != null) deleteButton.setVisibility(View.GONE);
                } else {
                    if (deleteButton != null) {
                        deleteButton.setVisibility(View.VISIBLE);
                        deleteButton.setOnClickListener(v -> {
                            dbHelper.deleteWeight(userId, item[0], item[1].replace("kg", ""));
                            refreshWeightList();
                            currentWeightText.setText(dbHelper.getLatestWeight(userId));
                        });
                    }
                }

                return view;
            }
        });
    }
}
